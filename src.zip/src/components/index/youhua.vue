<template>
  <div class="youhua">
  	<div class="imgs" v-for="(n,i) in goods" :key="i">
  		<img :src="n.url" alt=""><br>
  		<span>&yen;{{n.describe}}</span><br>
  		<span>{{n.induce}}</span>
  	</div>	
  </div>
</template>

<script>
export default {
  data(){
  	return{
  		goods:[
  			{
  				url:'/static/image/index/latent/art/youhua/1.jpg',
  				author:'陈尚昌',
  				describe:'悠远的天空',
  				induce:'布面油画 97.0*130.0cm'
  			},
  			{
  				url:'/static/image/index/latent/art/youhua/2.jpg',
  				author:'王笃涛',
  				describe:'52赫兹的绝唱',
  				induce:'布面油画 60.0*80.0cm'
  			},
  			{
  				url:'/static/image/index/latent/art/youhua/3.jpg',
  				author:'李龙飞',
  				describe:'一盘樱桃',
  				induce:'布面油画 30.0*30.0cm'
  			},
  			{
  				url:'/static/image/index/latent/art/youhua/4.jpg',
  				author:'曹继才',
  				describe:'从你的全世界路过',
  				induce:'布面油画 80.0*80.0cm'
  			},
  		]
  	}
  }
}
</script>

<style>

</style>