<template>
  <div class="setting">
  	<header>
  		<span></span>
  		<span>账户设置</span>
  		<span class="hid"></span>
  	</header>
  	<section>
  		<ol>
  			<li>
  				<span>头像</span><span><img></span>
  			</li>
  			<li class="msgInput">
  				<input type="text"><input type="button" value="确认" v-on:click="makeSureAvatar">
  			</li>
  			<li>
  				<span>昵称</span><span>{{nickname}}<span>&gt;</span></span>
  			</li>
  			<li>
  				<input type="text" v-model="inputNickname"><input type="button" value="确认" v-on:click="makeSureNickname">
  			</li>
  			<li>
  				<span>真实姓名</span><span>{{yourName}}<span>&gt;</span></span>
  			</li>
  			<li>
  				<input type="text" v-model="inputYourName"><input type="button" value="确认" v-on:click="makeSureYourName">
  			</li>
  			<li>
  				<span>性别</span><span>{{sex}}<span>&gt;</span></span>
  			</li>
  			<li>
  				<input type="text" v-model="inputSex"><input type="button" value="确认" v-on:click="makeSureSex">
  			</li>
  			<li>
  				<span>出生日期</span><span>{{birthDate}}<span>&gt;</span></span>
  			</li>
  			<li>
  				<input type="text" v-model="inputBirthDate"><input type="button" value="确认" v-on:click="makeSureBirthDate">
  			</li>
  		</ol>
  		<ol>
  			<li>
  				<span>手机</span><span>{{phoneNum}}<span>&gt;</span></span>
  			</li>
  			<li>
  				<input type="text" v-model="inputPhoneNum"><input type="button" value="确认" v-on:click="makeSurePhoneNum">
  			</li>
  			<li>
  				<span>邮件</span><span>{{mail}}<span>&gt;</span></span>
  			</li>
  			<li>
  				<input type="text" v-model="inputMail"><input type="button" value="确认" v-on:click="makeSureMail">
  			</li>
  			<li>
  				<span>绑定微信</span><span>{{bindWeiXin}}<span>&gt;</span></span>
  			</li>
  			<li>
  				<input type="text" v-model="inputBindWeiXin"><input type="button" value="确认" v-on:click="makeSureBindWeiXin">
  			</li>
  			<li>
  				<span>绑定微博</span><span>{{bingWeiBo}}<span>&gt;</span></span>
  			</li>
  			<li>
  				<input type="text" v-model="inputBingWeiBo"><input type="button" value="确认" v-on:click="makeSureBingWeiBo">
  			</li>
  		</ol>
  	</section>
  	<p class="logOut"><span>退出登录</span></p>
  </div>



</template>

<script>
export default {
  data(){
  	return{
  		Avatar:"",
  		nickname:"未设置",
  		yourName:"未设置",
  		sex:"未设置",
  		birthDate:"未设置",
  		phoneNum:"未设置",
  		mail:"未设置",
  		bindWeiXin:"未设置",
  		bingWeiBo:"未设置",
  		inputNickname:"",
  		inputYourName:"",
  		inputSex:"",
  		inputBirthDate:"",
  		inputPhoneNum:"",
  		inputMail:"",
  		inputBindWeiXin:"",
  		inputBingWeiBo:"",
  	}
  },
  methods:{
  	makeSureAvatar:function(){
  		this.nickname=this.inputNickname
  	},
  	makeSureNickname:function(){
  		this.nickname=this.inputNickname
  	},
  	makeSureYourName:function(){
  		this.yourName=this.inputYourName
  	},
  	makeSureSex:function(){
  		this.sex=this.inputSex
  	},
  	makeSureBirthDate:function(){
  		this.birthDate=this.inputBirthDate
  	},
  	makeSurePhoneNum:function(){
  		this.phoneNum=this.inputPhoneNum
  	},
  	makeSureMail:function(){
  		this.mail=this.inputMail
  	},
  	makeSureBindWeiXin:function(){
  		this.bindWeiXin=this.inputBindWeiXin
  	},
  	makeSureBingWeiBo:function(){
  		this.bingWeiBo=this.inputBingWeiBo
  	},
  }
}
</script>
<style scoped>
	*{
		margin: 0;
		padding: 0;
	}
	.hid{
		visibility: hidden;
	}
	ol,li{
		list-style-type: none;
		background-color: #fff;
		padding: 5px; 
	}
	ol{
		margin-top: 10px;
	}
	.setting{
		background-color: #eee;
	}
	header{
		width: 500px;
		background-color: #fff;
	}
	header,li,.logOut{
		display: flex;
		justify-content: space-between;
	}
	.logOut{
		color: red;
		text-align: center;
		background-color: #fff;
	}
	.logOut span{
		margin: auto;
	}
</style>