<template>
 	<div class="art">
  		<header>
	        <div class="slide">
	            <el-row :gutter="0">
	              	<el-col :span="4">
	                 	<img src="/static/image/index/latent/art/neum.png" alt="">
	              	</el-col>
	              	<el-col :span="16">
	                  	<span class="aite"><b>AITE ONLINE艺术博览会</b></span>
	              	</el-col>
	              	<el-col :span="4">
	                  	<el-dropdown>
	                  	  <span class="el-dropdown-link"><img src="/static/image/index/latent/art/gui.jpg" alt="" class="two">
	                  	  </span>
	                  	  <el-dropdown-menu slot="dropdown" trigger="click">
	                  	    <router-link to=""><el-dropdown-item>个人中心</el-dropdown-item></router-link>
	                  	    <router-link to=""><el-dropdown-item>我的订单</el-dropdown-item></router-link>
	                  	    <router-link to=""><el-dropdown-item>退出登录</el-dropdown-item></router-link>
	                  	  </el-dropdown-menu>
	                  	</el-dropdown>
	              	</el-col>
	            </el-row> 
	        </div>
        </header>
		<div class="lun">
			<Uper></Uper>
			<Down></Down>

			<!-- <el-carousel height="500px">
			    <el-carousel-item v-for="i in item">
			      	<router-link :to="i.path"><img :src="i.url" alt=""></router-link>
			    </el-carousel-item>
			</el-carousel>
			<p class="big"><b>AITE ONLINE</b>艺术博览会</p>
			<p>主旨与理念</p>
			<span>AITE ONLINE艺术博览会，是中国首个在互联网上展览展示的艺术博览会，AITEONLINE艺术博览会旨在将传统的艺术博览会模式进行创新，通过互联网模式让当代艺术广泛传播，这将成为传统艺术博览会的重要补充环节，更是艺术博览会未来的发展趋势。AITE ONLINE艺术博览会，将为您呈现多家艺术机构的知名艺术家作品、联合多位著名策展人策展不同主题的专业展览，联手上千位潜力艺术家展示海量的优秀艺术作品。</span>
			<div class="btn btnwhite"><router-link to="">了解更多</router-link></div>
			<div class="slide slidebgc">
				<el-row :gutter="0">
				    <el-col :span="6">
				        <router-link to="/index/gallery">参展机构</router-link>
				    </el-col>
				    <el-col :span="6">
				        <router-link to="/index/curetion">策展单元</router-link>
				    </el-col>
				    <el-col :span="6">
				        <router-link to="/index/public">公共项目</router-link>
				    </el-col>
				    <el-col :span="6">
				        <router-link to="/index/shede">艺术舍得</router-link>
				    </el-col>
				</el-row>
				<div class="view">
				 	<router-view/>
				</div>
				<div class="btnall btnwhite">浏览全部作品</div>
			</div>
			<div class="kuang">
				<p class="big"><b>参展机构</b>GALLERY</p>
				<div class="flex">
					<div class="imgs" v-for="n in goods">
						<img :src="n.url" alt=""><br>
						<span>{{n.induce}}</span>
					</div>
				</div>
				<div class="btn"><router-link to="">浏览全部</router-link></div>
			</div>
			<div class="kuang kuangbgc">
				<p class="big"><b>策展单元</b>CURATION</p>
				<div class="flex">
					<div class="imgs imgbgc" v-for="n in good">
						<img :src="n.url" alt=""><br>
						<span>{{n.author}}</span><br>
						<span>{{n.induce}}</span>
					</div>
				</div>
				<div class="btn btnwhite"><router-link to="">浏览全部</router-link></div>
			</div> -->
			<!-- <router-link to="/index/uper">uper</router-link> -->

			<!-- <router-link to="/index/down">down</router-link> -->
			<!-- <div>
				<p class="big"><b>公共项目</b>PUBLIC</p>
				<div class="slide slidebgc slideflex">
					<div><router-link to="/index/youhua">油画</router-link></div>
					<div><router-link to="/index/shuimo">水墨</router-link></div>
					<div><router-link to="/index/diaosu">雕塑</router-link></div>
					<div><router-link to="/index/banhua">版画</router-link></div>
					<div><router-link to="/index/qita">其他</router-link></div>
				</div>	
				<div class="view">
					<router-view/>
				</div>
				<div class="btn"><router-link to="">浏览全部</router-link></div>
			</div>
			<div>
				<p class="big"><b>艺术舍得</b>SHEDE</p>
				<div class="pay">购买展览通票</div>
			</div>
			<div>
				<span><b>发布会回顾</b></span>
			</div> -->

			<!-- <router-view/> -->
		</div>
  	</div>
</template>

<script>
import Uper from '@/components/index/uper'
import Down from '@/components/index/down'
import Gallery from '@/components/index/gallery'
import Curetion from '@/components/index/curetion'
import Public from '@/components/index/public'
import Shede from '@/components/index/shede'
export default {
	routes:[
		    			{
		    				path:'/index/gallery',
		    				name:'Gallery',
		    				component:Gallery
		    			},
		    			{
		    				path:'/index/curetion',
		    				name:'Curetion',
		    				component:Curetion
		    			},
		    			{
		    				path:'/index/public',
		    				name:'Public',
		    				component:Public
		    			},
		    			{
			    			path:'/index/shede',
			    			name:'Shede',
			    			component:Shede
			    		},
	],
	redirect:'/index/gallery',
  	data(){
  		return{

  			// item:[
  			// 	{
  			// 		url:'/static/image/index/latent/art/1.jpg',
  			// 		path:'index/art'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/2.jpg',
  			// 		path:'index/fall'
  			// 	}
  			// ],
  			// goods:[
  			// 	{
  			// 		url:'/static/image/index/latent/art/7.jpg',
  			// 		induce:'TONG GALLERY+PROJECTS'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/8.jpg',
  			// 		induce:'星空间'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/9.jpg',
  			// 		induce:'逸空间'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/10.jpg',
  			// 		induce:'博而励画廊'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/11.jpg',
  			// 		induce:'当代唐人艺术中心'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/12.jpg',
  			// 		induce:'艺·凯旋画廊'
  			// 	},
  			// ],
  			// good:[
  			// 	{
  			// 		url:'/static/image/index/latent/art/13.jpg',
  			// 		author:'朱彤',
  			// 		induce:'目光所及-中国新绘画'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/14.jpg',
  			// 		author:'姬忠鹏',
  			// 		induce:'自在语境-当代青年绘画邀请展'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/15.jpg',
  			// 		author:'李玉军',
  			// 		induce:'无形之态-当下的抽象与新表现艺术展'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/16.jpg',
  			// 		author:'李超',
  			// 		induce:'调和-学院青年水墨展'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/17.jpg',
  			// 		author:'杨彪',
  			// 		induce:'似是而非-新雕塑邀请展'
  			// 	},
  			// 	{
  			// 		url:'/static/image/index/latent/art/18.jpg',
  			// 		author:'葛亚楠',
  			// 		induce:'棱镜-反看内部的切面'
  			// 	},
  			// ]
  		}
  	},
  	components:{
  		Uper,
  		Down
  	}
}
</script>

<style scroped lang="less">
.art{
	width: 500px;
	p{
		text-align: center;
	}
	.big{
		padding-top: 30px;
		font-size: 25px;
	}
	header{
		width: 500px;
		height: 50px;
		z-index: 10;
		background-color: #fec400;
		position: fixed;
		top:0;
	}
	.slide{
		position: relative;
		text-align: center;
		a{
			line-height: 50px;
			text-decoration: none;
			padding: 10px 30px;
			color:#333;
			background-color: #eeeeee;
		}
		img{
			height: 30px;
			margin-top: 10px;
		}
		.aite{
			display: block;
			padding-top: 15px;
		}
		.two{
			border-radius: 50%;
		}
	}
	.slidebgc{
		.router-link-active{
			background-color:  #fec400;
		}
		.view{
			height: 400px;
			background-color: #fec400;
			img{
				height: 250px;
				width: 480px;
				margin-top: 20px;
				background-color: #cb9d00;
			}
		}
	}
	.btn{
		width: 80px;
		border:1px solid #333;
		padding:10px 20px;
		background-color: #fec400;
		position: relative;
		text-align: center;
		a{
			text-decoration: none;
			color:#333;
			font-weight: bold;	
		}
		
	}
	.btnall{
		width:100px;
		padding:10px 20px;
		position: relative;
		bottom:80px;
		left: 200px;
	}
	.btnwhite{
		background-color: #fff;
	}
	.pay{
		width:100px;
		padding: 10px;
		border-radius: 5px;
		background-color: #fec400;
	}
	// .lun{
	// 	img{
	// 		width: 500px;
	// 	}
	// 	.kuang{
	// 		text-align: center;
	// 		.btn{
	// 			left:200px;
	// 			margin: 30px 0;
	// 		}
	// 		.flex{
	// 			display: flex;
	// 			justify-content: space-around;
	// 			align-content: space-around;
	// 			flex-wrap: wrap;
	// 			.imgs{
	// 				width: 240px;
	// 				img{
	// 					width:100%;
	// 				}
	// 			}
	// 		}	
	// 	}
	// 	.kuangbgc{
	// 		background-color: #fec400;
	// 		.btn{
	// 			bottom:20px;
	// 		}
	// 		.imgbgc{
	// 			margin: 10px 0;
	// 			text-align: left;
	// 			font-size: 12px;
	// 			background-color: #fff;
	// 			padding-bottom: 30px;
	// 		}
	// 	}
	// 	.slideflex{
	// 		display: flex;
	// 		justify-content: space-between;
	// 		a{
	// 			padding: 10px 30px;
	// 		}
	// 	}
	// } 
}

</style>