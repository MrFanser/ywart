<template>
  <div class="uper">
  	<div>
  		<p class="big"><b>公共项目</b>PUBLIC</p>
  		<div class="slide slidebgc slideflex">
  			<div><router-link to="/index/youhua">油画</router-link></div>
  			<div><router-link to="/index/shuimo">水墨</router-link></div>
  			<div><router-link to="/index/diaosu">雕塑</router-link></div>
  			<div><router-link to="/index/banhua">版画</router-link></div>
  			<div><router-link to="/index/qita">其他</router-link></div>
  		</div>	
  		<div class="view">
  			<router-view/>
  		</div>
  		<div class="btn"><router-link to="">浏览全部</router-link></div>
  	</div>
  	<div>
  		<p class="big"><b>艺术舍得</b>SHEDE</p>
  		<div class="pay">购买展览通票</div>
  	</div>
  	<div>
  		<span><b>发布会回顾</b></span>
  	</div>
  </div>
</template>

<script>
export default {
  
}
</script>

<style scroped lang="less">

</style>