<template>
	 <div class="gallery">
	 	<img src="/static/image/index/latent/art/3.png" alt="">
	</div>
</template>

<script>
export default {
  
}
</script>

<style>

</style>