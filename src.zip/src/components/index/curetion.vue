<template>
  <div class="curation">
  	<img src="/static/image/index/latent/art/4.png" alt="">
  </div>
</template>

<script>
export default {
  
}
</script>

<style>

</style>