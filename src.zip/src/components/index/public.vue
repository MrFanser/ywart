<template>
  <div class="public">
  	<img src="/static/image/index/latent/art/5.png" alt="">
  </div>
</template>

<script>
export default {
  
}
</script>

<style scoped lang="less">

</style>