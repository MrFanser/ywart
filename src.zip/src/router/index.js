import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/components/Index'
import Ind from '@/components/ind'
import Rudi from '@/components/index/rudi'
import Latent from '@/components/index/latent'
import Recoment from '@/components/index/recoment'
import Header from '@/components/index/header'
import Kinds from '@/components/kinds'
import Arts from '@/components/arts'
import Car from '@/components/car'
import Me from '@/components/me'
import Gkj from '@/components/index/gkj'
import Fall from '@/components/index/fall'
import Princess from '@/components/index/princess'
import Phil from '@/components/phil'
import Art from '@/components/index/art'
// import Gallery from '@/components/index/gallery'
// import Curetion from '@/components/index/curetion'
// import Public from '@/components/index/public'
// import Shede from '@/components/index/shede'
// import Youhua from '@/components/index/youhua'
// import Shuimo from '@/components/index/shuimo'
// import Diaosu from '@/components/index/diaosu'
// import Banhua from '@/components/index/banhua'
// import Qita from '@/components/index/qita'
import Setting from '@/components/index/setting'
import Uper from '@/components/index/uper'
import Down from '@/components/index/down'

Vue.use(Router)

export default new Router({
    routes: [
    	{
      	path: '/',
     	name: 'Index',
     	component: Index,
     	children:[
     		{
     		 	path:'/header',
     		 	name:'Header',
     		 	component:Header,
     		 	children:[
     		 		{
     		 			path:'/ind',
     		 			name:'Ind',
     		 			component:Ind
     		 		},
     		 		{
     		 			path:'/index/recoment',
     		 			name:'Recoment',
     		 			component:Recoment,
     		 		},
     		 		{
     		 			path:'/index/rudi',
     		 			name:'Rudi',
     		 			component:Rudi
     		 		},
     		 		{
     		 			path:'/index/latent',
     		 			name:'Latent',
     		 			component:Latent
     		 		},
     		 	],
     		 	redirect:'/ind'
     		},
     		{
     		 	path:'/kinds',
     		 	name:'Kinds',
     		 	component:Kinds
     		},
     		{
     		 	path:'/arts',
     		 	name:'Arts',
     		 	component:Arts
     		},
     		{
     		 	path:'/car',
     		 	name:'Car',
     		 	component:Car
     		},
     		{
     		 	path:'/me',
     		 	name:'Me',
     		 	component:Me
     		},
        ],
      	redirect:'/header'
    },
    
    {
    	path:'/index/gkj',
    	name:'Gkj',
    	component:Gkj
    },
    {
    	path:'/index/fall',
    	name:'Fall',
    	component:Fall
    },
    {
    	path:'/index/princess',
    	name:'Princess',
    	component:Princess
    },
    {
    	path:'/phil',
    	name:'Phil',
    	component:Phil
    },
    {
    	path:'/index/art',
    	name:'Art',
    	component:Art,
    	children:[
    		{
    			path:'/index/uper',
    			name:'Uper',
    			component:Uper,
    			// children:[
	    			// {
	    			// 	path:'/index/gallery',
	    			// 	name:'Gallery',
	    			// 	component:Gallery
	    			// },
	    			// {
	    			// 	path:'/index/curetion',
	    			// 	name:'Curetion',
	    			// 	component:Curetion
	    			// },
	    			// {
	    			// 	path:'/index/public',
	    			// 	name:'Public',
	    			// 	component:Public
	    			// },
	    			// {
		    		// 	path:'/index/shede',
		    		// 	name:'Shede',
		    		// 	component:Shede
		    		// },
    			// ],
    			// redirect:'/index/gallery',
    		},
    		{
    			path:'/index/down',
    			name:'Down',
    			component:Down,
    			// children:[
			    	// {
		    		// 	path:'/index/youhua',
		    		// 	name:'Youhua',
		    		// 	component:Youhua
		    		// },
		    		// {
		    		// 	path:'/index/shuimo',
		    		// 	name:'Shuimo',
		    		// 	component:Shuimo
		    		// },
		    		// {
		    		// 	path:'/index/diaosu',
		    		// 	name:'Diaosu',
		    		// 	component:Diaosu
		    		// },
		    		// {
		    		// 	path:'/index/banhua',
		    		// 	name:'Banhua',
		    		// 	component:Banhua
		    		// },
		    		// {
		    		// 	path:'/index/qita',
		    		// 	name:'Qita',
		    		// 	component:Qita
		    		// }	
    			// ],
    			// redirect:'/index/youhua',
    		},
    	],
    },
    {
    	path:'/index/setting',
    	name:'Setting',
    	component:Setting
    }
  ]
})
